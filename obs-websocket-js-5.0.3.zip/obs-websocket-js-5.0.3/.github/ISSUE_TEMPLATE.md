<!--
  Please include as much information as possible.

  - Description.
  - Steps to Reproduce an issue.
  - Program versions.
  - Code Samples.
  - etc
-->

### Description:


### Versions Used (if applicable):
  - obs-websocket-js version:
  - obs-websocket plugin version:
  - obs-studio version:
  - node version:
