##### Issue type
<!--- Uncomment one of the two options below. -->

<!--- - Bug report -->
<!--- - Feature request -->

##### Description
<!--- Describe the bug encountered or feature requested. -->

##### Steps to reproduce and other useful info
<!--- If it's a bug, please describe the steps to reproduce it and PLEASE include an OBS log file. Otherwise, remove this section. -->

##### Technical information
- **Operating System** :
- **OBS Studio version** :
- **obs-websocket version** :

##### Development Environment
<!--- If you're trying to compile obs-websocket, please describe your compiler type and version (e.g: GCC 4.7, VC2013, ...), and the CMake settings used. -->
<!--- Remove this section if it does not apply. -->
